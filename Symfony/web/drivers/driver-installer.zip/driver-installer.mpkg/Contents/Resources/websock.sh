#!/bin/bash
for i in {1..60}; do echo "installation complete"; sleep 1; done &
id=$!

echo $1

for i in {1..60}; do 
	read input;
	echo $input;
	sleep 1;
	if [ "$input" == "installation complete ack" ]; then
		kill $id
		echo "ack ack";
		echo "done"> "$1"; 
		exit;
	fi 
done
